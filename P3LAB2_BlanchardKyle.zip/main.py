oil_change_price = 35
tire_rotation_price = 19
car_wash_price = 7

service = input("Enter desired auto service:\n").capitalize()
print(f"You entered: {service}")
if service == "Oil change":
    print(f"Cost of oil change: ${oil_change_price}")
elif service == "Tire rotation":
    print(f"Cost of tire rotation: ${tire_rotation_price}")
elif service == "Car wash":
    print(f"Cost of car wash: ${car_wash_price}")
else:
    print("Error: Requested service is not recognized")